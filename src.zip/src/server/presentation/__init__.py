"""
Exports controller classes for the lottery system.
"""

from .GenerateTicketController import GenerateTicketController

__all__ = [
    "GenerateTicketController"
]