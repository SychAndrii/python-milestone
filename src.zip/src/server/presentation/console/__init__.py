"""
Exports console presentation classes for the lottery system.
"""

from .Console import Console

__all__ = [
    "Console"
]