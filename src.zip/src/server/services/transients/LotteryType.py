from enum import Enum

class LotteryType(Enum):
    LOTTO_MAX = "max"
    DAILY_GRAND = "grand"
    LOTTARIO = "lottario"